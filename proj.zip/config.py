# 配置文件
IP_CAMERA_URL = ""
YOLO_MODEL_PATH = ""
# 报警设置
ALERT_FRAMES_THRESHOLD = 5  # 连续帧阈值
ALERT_COOLDOWN_TIME = 60  # 警报冷却时间（秒）
